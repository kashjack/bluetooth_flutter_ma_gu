package com.kashjack.carbluetooth.bluetooth_flutter_ma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
